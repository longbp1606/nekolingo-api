export enum UserRoleEnum {
	USER,
	ADMIN,
}
