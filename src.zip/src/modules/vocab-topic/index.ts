export * from "./vocab-topic.service";
export * from "./vocab-topic.module";
