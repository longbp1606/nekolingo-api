export * from "./create-vocabulary.request";
export * from "./update-vocabulary.request";
export * from "./vocabulary.response";
