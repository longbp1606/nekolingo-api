export * from "./vocabulary.service";
export * from "./vocabulary.module";
